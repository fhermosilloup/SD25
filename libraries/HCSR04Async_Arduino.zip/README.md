# HCSR04Async

Arduino library for HC-SR04 on the **original ESP32 family**, using the ESP-IDF MCPWM Capture peripheral to timestamp ECHO rising/falling edges.

## Target / requirements

- Arduino-ESP32 **3.x** (ESP-IDF 5.x MCPWM capture driver)
- Classic ESP32 such as ESP32-WROOM-32 / DevKit V1
- HC-SR04 (ECHO must be level-shifted to 3.3 V)

This first version targets the classic ESP32 MCPWM capture API. Other ESP32 variants may have different MCPWM resources and need validation.

## API

```cpp
HCSR04Async sonar(TRIG_PIN, ECHO_PIN, intervalMs=60, timeoutUs=30000);
sonar.begin();
sonar.start();

if (sonar.update()) {
    // At least one new measurement completed since previous update().
}

size_t pending = sonar.available();

HCSR04Async::Measurement m;
while (sonar.read(m)) {
    if (m.valid) use(m.distanceCm);
}
```

`available()` counts queued, unread results, including timeout records.
`read(Measurement&)` consumes the oldest result.
`update()` is non-waiting; it schedules the next trigger and checks for timeout.
`dropped()` reports how many oldest entries were overwritten because the ring buffer was full.

## Buffer behavior

The ring buffer has 16 entries by default. When full, the oldest unread entry is discarded to preserve the newest data. Override `HCSR04ASYNC_BUFFER_SIZE` before including the library to change its capacity.

## Wiring

- HC-SR04 VCC -> 5 V
- HC-SR04 GND -> ESP32 GND
- TRIG -> selected ESP32 output GPIO
- ECHO -> selected ESP32 input GPIO through a divider/level shifter

Example divider: 1 kΩ from ECHO to GPIO, 2 kΩ from GPIO to GND.

## Notes

- MCPWM hardware timestamps the ECHO edges. The short 10 µs TRIG pulse is generated in software.
- The library does not use `pulseIn()` or poll ECHO in the main loop.
- Keep the measurement interval at 60 ms or longer to avoid overlapping ultrasonic bursts.
- `update()` must be called frequently. The callback itself completes and queues a measurement asynchronously.
- A timeout is queued as an invalid measurement (`valid == false`, `distanceCm == NAN`).
- Validate the library on the exact Arduino-ESP32 core/chip revision before deploying. The MCPWM capture callback runs in ISR context and only performs bounded work.
