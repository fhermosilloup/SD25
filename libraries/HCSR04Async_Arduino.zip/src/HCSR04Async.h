#pragma once

#include <Arduino.h>
#include "driver/mcpwm_cap.h"

#ifndef HCSR04ASYNC_BUFFER_SIZE
#define HCSR04ASYNC_BUFFER_SIZE 16
#endif

class HCSR04Async {
public:
    struct Measurement {
        uint32_t durationUs;
        float distanceCm;
        bool valid;
        uint32_t sequence;
    };

    HCSR04Async(uint8_t trigPin, uint8_t echoPin,
                uint32_t intervalMs = 60,
                uint32_t timeoutUs = 30000);

    ~HCSR04Async();

    bool begin();
    void start();
    void stop();

    // Returns true if one or more new measurements completed since
    // the previous call to update().
    bool update();

    // Number of completed measurements waiting in the ring buffer.
    size_t available() const;

    // Removes the oldest queued measurement.
    bool read(Measurement &measurement);

    // Convenience overload: returns distance in cm and validity.
    bool read(float &distanceCm);

    uint32_t dropped() const;
    bool isRunning() const;
    const char *error() const;

private:
    static bool IRAM_ATTR onCapture(mcpwm_cap_channel_handle_t channel,
                                    const mcpwm_capture_event_data_t *edata,
                                    void *userCtx);

    bool pushFromISR(const Measurement &m);
    void pushTimeout();
    void trigger();

    uint8_t _trigPin;
    uint8_t _echoPin;
    uint32_t _intervalMs;
    uint32_t _timeoutUs;
    uint32_t _resolutionHz = 0;

    mcpwm_cap_timer_handle_t _capTimer = nullptr;
    mcpwm_cap_channel_handle_t _capChannel = nullptr;

    portMUX_TYPE _mux = portMUX_INITIALIZER_UNLOCKED;

    Measurement _buffer[HCSR04ASYNC_BUFFER_SIZE];
    volatile size_t _head = 0;
    volatile size_t _tail = 0;
    volatile size_t _count = 0;
    volatile uint32_t _dropped = 0;
    volatile uint32_t _completed = 0;
    uint32_t _lastUpdateCompleted = 0;

    volatile bool _haveRisingEdge = false;
    volatile uint32_t _risingTick = 0;
    volatile bool _measurementActive = false;

    bool _begun = false;
    bool _running = false;
    uint32_t _lastTriggerMs = 0;
    uint32_t _triggerMs = 0;
    const char *_error = "OK";
};
