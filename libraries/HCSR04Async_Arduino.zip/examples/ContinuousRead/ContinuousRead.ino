#include <Arduino.h>
#include <HCSR04Async.h>

// HC-SR04:
// TRIG -> GPIO5
// ECHO -> GPIO18 through a voltage divider (5 V to 3.3 V)
// VCC -> 5 V, GND -> GND

HCSR04Async sonar(5, 18, 60, 30000);

void setup() {
    Serial.begin(115200);

    if (!sonar.begin()) {
        Serial.print("HC-SR04 init error: ");
        Serial.println(sonar.error());
        while (true) delay(1000);
    }

    sonar.start();
}

void loop() {
    if (sonar.update()) {
        Serial.printf("Completion event. Pending: %u\n",
                      (unsigned)sonar.available());
    }

    HCSR04Async::Measurement m;
    while (sonar.read(m)) {
        if (m.valid) {
            Serial.printf("#%lu: %.2f cm (%lu us)\n",
                          (unsigned long)m.sequence,
                          m.distanceCm,
                          (unsigned long)m.durationUs);
        } else {
            Serial.printf("#%lu: timeout / no echo\n",
                          (unsigned long)m.sequence);
        }
    }

    // Other application work can run here.
}
